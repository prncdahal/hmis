# hellostatic
My personal starter template using gulp
